import {Router} from "express";
const router = Router()

var artistas=["Drake", "Kendrick Lamar", "J. Cole", "Taylor Swift", "Adele", "The Weeknd"]

router.get("/", function(req,res){
    res.render("home",{artistas})
})

router.get("/informacion/:c", function (req, res){
    var c = req.params.c
    console.log(c)
    res.render("informacion", {c})
})

router.get("/contactanos", function (req, res){
    res.render("contactanos")
})
router.post("/contactanos", function (req, res){
var nombre=req.body.nombre
var edad=req.body.edad
console.log("Nombre: "+nombre+"Edad: "+ edad)
res.render("respuesta", {nombre, edad})
})

export default router